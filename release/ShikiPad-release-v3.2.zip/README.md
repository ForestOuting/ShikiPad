# ShikiPad

ShikiPad is a native Windows controller-to-keyboard and mouse mapper. It works best with PlayStation controllers. DualSense and DualShock 4 expose the full ShikiPad feature set, while Xbox controllers work through XInput and are limited by Windows system behavior.

Chinese documentation: [README.zh-CN.md](README.zh-CN.md)

## Controller Choice

Use a DualSense or DualShock 4 controller when possible. This gives ShikiPad the most complete input surface, including Sony-specific buttons such as Home, Create/Share, Options/Menu, and DualSense Mute.

Many third-party controllers support multiple modes. If yours can switch modes, PS4 / DualShock 4 mode is recommended for ShikiPad. Xbox mode can still work for normal mapping, but Windows owns parts of the Xbox stack. In particular, the Xbox Guide/Home button cannot be read through XInput, and HidHide usually cannot hide Xbox controllers at the HID device layer.

ShikiPad now requires Interception for keyboard and mouse output. This does not stop Xbox controllers from being read, because Xbox input is read through XInput and output is sent through Interception. The practical limitation is not Interception, but the Windows XInput/Xbox stack.

## Driver And HidHide Order

Recommended setup order:

1. Connect the controller once and confirm Windows can see it.
2. Install Interception with `install_driver.bat` as administrator.
3. Restart Windows.
4. Run `ShikiPad.exe` as administrator and confirm it can send keyboard and mouse output.
5. For PlayStation controllers, configure HidHide to prevent system or game double input.
6. Unplug and reconnect the controller after HidHide changes.

HidHide setup for PlayStation controllers:

1. In `Applications`, add the exact path to `ShikiPad.exe`.
2. Uncheck `Inverse application cloak`.
3. In `Devices`, check the target PlayStation controller. A red lock icon should appear.
4. If the target controller is unclear, connect the controller successfully first, then temporarily check all matching game controllers.
5. Check `Filter-out disconnected`, `Gaming devices only`, and `Enable device hiding`.
6. Close HidHide, then unplug and reconnect the controller.

To let Windows and games see the controller normally again, re-check `Inverse application cloak` or disable `Enable device hiding`, then unplug and reconnect the controller.

## Release Package

A release archive contains only:

| File | Purpose |
|---|---|
| `ShikiPad.exe` | Main program |
| `install_driver.bat` | Interception driver installer helper |
| `interception.dll` | Interception runtime |
| `driver/install-interception.exe` | Interception driver installer |
| `README.md` / `README.zh-CN.md` | Documentation |

ShikiPad may create `shikipad.default` after launch. It only stores the default controller profile and is not part of the release package.

## Install

1. Extract the release archive.
2. Right-click `install_driver.bat` and choose `Run as administrator`.
3. Restart Windows after `Installation complete!`.
4. Run `ShikiPad.exe` as administrator.
5. Type `1` to `8` to select a controller profile. You may save it as the default launch profile.

## Console Pages

| Page | Enter | Esc |
|---|---|---|
| Controller selection | Confirm selection | Exit |
| Home | Open mapping manual | Return to controller selection |
| Mapping manual | Return home | Exit ShikiPad |

Closing the console window also exits and releases held keyboard and mouse inputs.

## Mouse And System Buttons

| Controller input | Output |
|---|---|
| Right stick | Mouse movement |
| L3 | Left mouse button |
| R3 | Right mouse button with a short cursor freeze on press |
| Left stick up / down | Mouse wheel |
| Sony Create / Share | `Right Alt` |
| Sony Options / Menu | `Right Ctrl` |
| Sony Home | `Right Shift` |
| DualSense Mute | `Caps Lock` |
| Share/Create/View + Options/Menu for about 1 second | Enable / disable ShikiPad |

## Voice Input

If controller typing still feels difficult, pair ShikiPad with voice input software such as Typeless or Shandian Shuo. PlayStation controllers are especially convenient here: Share maps to `Right Alt`, Options/Menu maps to `Right Ctrl`, and Home maps to `Right Shift`, so voice input shortcuts can be triggered without leaving the controller. The built-in microphone on supported PlayStation controllers also sits close to your mouth and can produce good recognition results in a quiet room.

## Left Stick

| Direction | Output |
|---|---|
| Left | `Shift` |
| Down-left | `Ctrl` |
| Down-right | `Left Alt` |
| Right | `Win` |
| Up-left | `Esc` |
| Up-right | Fn layer |
| Up / Down | Mouse wheel |

Fn turns number-row keys into `F1` to `F12`: `1..0` map to `F1..F10`, `-` maps to `F11`, and `=` maps to `F12`.

When the left stick enters a modifier direction, ShikiPad locks that direction until the stick returns to the deadzone. Rotating the stick around the edge will not drift from `Shift` to `Ctrl`, `Alt`, `Win`, or `Esc`. This makes held shortcuts stable: choose the modifier direction, keep holding the stick, then press the action key. Return to the deadzone to release it.

## Clutch

Normally, the left stick holds one modifier at a time. Clutch collects multiple modifiers and releases them together.

While clutch is active, the currently collected modifiers remain held even if the left stick moves away from their original direction. This lets you keep a modifier, move the stick up or down for wheel input, or move to another modifier direction to add it to the stack. Releasing clutch releases the collected modifiers.

| Controller | Activate / hold |
|---|---|
| DualSense / DualShock 4 | Short-tap Touchpad to toggle, or long-press to hold |
| Xbox | Short-tap View/Back or Menu/Start to toggle, or long-press to hold |

## Typing Layers

The v3 release maps letters around familiar keyboard positions. This keeps layouts such as `WASD` and `IJKL` recognizable instead of sorting every letter purely by frequency.

The columns in the following tables correspond to: `↑`, `→`, `□/X`, `△/Y`, `←`, `↓`, `×/A`, `○/B`.

| Layer | ↑ | → | □/X | △/Y | ← | ↓ | ×/A | ○/B |
|---|---|---|---|---|---|---|---|---|
| Base | ↑ | → | Space | Backspace | ← | ↓ | Enter | Tab |
| R1 / RB | o | p | j | i | n | m | k | l |
| L1 / LB | w | d | q | e | a | s | z | x |
| R2 / RT | 0 | g | y | u | - | = | b | h |
| L2 / LT | r | f | t | 1 | c | v | 3 | 2 |
| R1 + L1 | 4 | , | . | 7 | 5 | 6 | 9 | 8 |
| L2 + R2 | + | / | & | * | _ | ^ | $ | % |
| L1 + R2 | [ | ] | ! | ? | { | } | @ | # |
| R1 + L2 | ( | ) | ; | ' | < | > | backtick | \ |

The program sends physical keycodes. Characters requiring Shift (", :, |, ~) can be entered by holding the left stick `Shift` direction and pressing the corresponding base key (', ;, \, backtick).

Base-layer keys repeat while held. Character layers are virtual taps: one press sends one key stroke, and holding does not repeat.

If multiple layer buttons are pressed on the same polling timestamp, tie priority is `R1 > L1 > R2 > L2`. Combo formation still only considers the latest two active layer buttons after that priority sort.

## Troubleshooting

### No keyboard or mouse output

Install Interception, restart Windows, and run `ShikiPad.exe` as administrator.

### System or game double input

If Windows still sees the physical controller while ShikiPad is running, the same stick movement can be handled twice: once by ShikiPad and once by Windows or the focused app. Typical symptoms include left-stick `Alt` plus `Tab` jumping unpredictably between windows, or the left-stick `Win` modifier failing because Windows treats controller input as Start menu, taskbar, or app icon navigation. Configure HidHide as described above so only ShikiPad can see the PlayStation controller. Xbox controllers use XInput, so HidHide usually cannot hide them at the HID layer.

## Timing Model Parameters

ShikiPad uses short time windows to absorb human input errors when typing quickly.

| Parameter | Default | Purpose |
|---|---:|---|
| `comboLayerWindowMs` | 35 ms | Maximum interval for two layer buttons to form a combo layer |
| `actionLayerGraceMs` | 45 ms | Grace window between action key and layer recognition |
| `actionLayerPostGraceMs` | 15 ms | Grace window after a layer is released before a new layer is pressed |
| `layerTakeoverWindowMs` | 30 ms | Cumulative body cap; after the 20 ms cutoff lands inside a boundary old layer body, backward tracing can continue only until cumulative body occupancy reaches 30 ms |
| `layerOccupancyCarryCutoffMs` | 20 ms | Cumulative body cutoff for backward layer tracing; total lookback is still `actionLayerGraceMs`, but once cumulative body occupancy reaches this cutoff, tracing can continue only inside the current boundary body up to `layerTakeoverWindowMs` and cannot cross into its pre-window or older layers |
| `actionLayerSwitchGuardMs` | 35 ms | Suppress residual mis-touches when switching layers after a character is typed |

Combo layers are treated as their own layers: the same physical single-key press that helps form a combo still occupies the 45 ms timeline, but it does not count as that combo layer's own body accumulation and cannot trigger that combo layer's 20 ms / 30 ms body limits.
